# Gzim Sinani — Website

This is a static, responsive bilingual portfolio website (Italian / English).

## Preview locally
1. Unzip the project.
2. Open `index.html` in a browser.

## Before publishing — personalize these items
- Replace the sample portfolio photos in `index.html` with your own photography.
- Replace the portrait image in the About section with your own photo.
- Change `hello@gzimsinani.com` to your real contact email.
- Add your Instagram / TikTok / LinkedIn links if you want them shown.
- Update the About text if you want a more personal biography.

The current photos are visual placeholders loaded from Unsplash; they are not Gzim's own work.

## Publish free with Netlify
1. Create an account at https://app.netlify.com/
2. Choose **Add new site** → **Deploy manually** (or drag-and-drop deploy).
3. Drag the unzipped website folder (the folder containing `index.html`) into the upload area.
4. Netlify will give you a temporary `*.netlify.app` address.

## Connect Namecheap domain
1. In Netlify, open your site → **Domain management** → **Add a domain**.
2. Enter `gzimsinani.com` and follow Netlify's domain setup instructions.
3. In Namecheap, open **Domain List** → **Manage** next to `gzimsinani.com` → **Advanced DNS**.
4. Add/update the DNS records exactly as Netlify instructs. Do not guess the values; Netlify may show different records for your site.
5. Set `gzimsinani.com` as the primary domain in Netlify and enable HTTPS once DNS has propagated.

Official guides:
- Netlify manual deploy: https://docs.netlify.com/welcome/add-new-site/
- Netlify custom domains: https://docs.netlify.com/manage/domains/
- Namecheap DNS: https://www.namecheap.com/support/knowledgebase/article.aspx/319/2237/how-can-i-set-up-a-url-redirect-for-a-domain/

Important: DNS changes can take some time to propagate. Keep the current nameservers unless Netlify specifically instructs you to change them.
